"use client"

import type React from "react"
import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Progress } from "@/components/ui/progress"
import { X, Plus, Loader2 } from "lucide-react"

const API_URL = "https://1ec1f0191830.ngrok-free.app/api/diagnosis"

interface Symptom {
  id: string
  text: string
}

interface Disease {
  name: string
  likelihood?: number
  reason?: string
}

interface APIResponse {
  conditions: Disease[]
  clarifying_questions: string[]
}

export default function MedicalAIAssistant() {
  const [symptoms, setSymptoms] = useState<Symptom[]>([])
  const [currentSymptom, setCurrentSymptom] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [apiResponse, setApiResponse] = useState<APIResponse | null>(null)
  const [selectedDisease, setSelectedDisease] = useState<Disease | null>(null)

  const addSymptom = () => {
    if (!currentSymptom.trim()) return

    const newSymptom: Symptom = {
      id: Date.now().toString(),
      text: currentSymptom.trim(),
    }
    setSymptoms([...symptoms, newSymptom])
    setCurrentSymptom("")
  }

  const removeSymptom = (id: string) => {
    setSymptoms(symptoms.filter((s) => s.id !== id))
  }

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter") {
      addSymptom()
    }
  }

  const handleSubmit = async () => {
    if (symptoms.length === 0) return

    setIsLoading(true)
    setApiResponse(null)
    setSelectedDisease(null)

    try {
      const response = await fetch(API_URL, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "ngrok-skip-browser-warning": "true",
        },
        body: JSON.stringify({
          symptoms: symptoms.map((s) => s.text),
        }),
      })

      if (!response.ok) {
        throw new Error(`خطا در سرور: ${response.status}`)
      }

      const data = await response.json()
      setApiResponse({
        conditions: data.conditions || [],
        clarifying_questions: data.clarifying_questions || [],
      })
    } catch (error) {
      alert("خطا در اتصال به سرور. لطفاً دوباره تلاش کنید.")
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-gray-50 p-4">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Intelligent Medicais</h1>
        </div>

        {/* Symptom Entry */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="text-xl">Symptom Entry</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-wrap gap-2 mb-4">
              {symptoms.map((symptom) => (
                <Badge
                  key={symptom.id}
                  variant="secondary"
                  className="px-3 py-1 text-sm bg-gray-200 hover:bg-gray-300 cursor-pointer"
                >
                  {symptom.text}
                  <X className="h-3 w-3 ml-2 hover:text-red-600" onClick={() => removeSymptom(symptom.id)} />
                </Badge>
              ))}
            </div>
            <div className="flex gap-2">
              <Input
                value={currentSymptom}
                onChange={(e) => setCurrentSymptom(e.target.value)}
                onKeyPress={handleKeyPress}
                placeholder="Enter symptom..."
                className="flex-1"
                disabled={isLoading}
              />
              <Button onClick={addSymptom} variant="outline" size="sm" disabled={isLoading}>
                <Plus className="h-4 w-4" />
              </Button>
              <Button onClick={handleSubmit} disabled={symptoms.length === 0 || isLoading}>
                {isLoading ? (
                  <>
                    <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                    Analyzing...
                  </>
                ) : (
                  "Submit"
                )}
              </Button>
            </div>
          </CardContent>
        </Card>

        {apiResponse && (
          <>
            <Card className="mb-6">
              <CardHeader>
                <CardTitle className="text-xl">Potential Conditions</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                {apiResponse.conditions.map((disease, index) => (
                  <div
                    key={index}
                    className="flex items-center justify-between p-3 bg-gray-100 rounded-lg hover:bg-gray-200 cursor-pointer transition-colors"
                    onClick={() => setSelectedDisease(disease)}
                  >
                    <div className="flex items-center gap-3">
                      <span className="font-medium">{disease.name}</span>
                      {disease.likelihood && (
                        <Badge variant="outline" className="text-xs">
                          {Math.round(disease.likelihood * 100)}%
                        </Badge>
                      )}
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>

            {selectedDisease && (
              <Card className="mb-6">
                <CardHeader>
                  <CardTitle className="text-xl">Disease Details</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="bg-gray-50 p-4 rounded-lg">
                    <h3 className="text-xl font-bold mb-4">{selectedDisease.name}</h3>

                    <div className="space-y-4">
                      {selectedDisease.likelihood && (
                        <div>
                          <div className="flex justify-between items-center mb-2">
                            <span className="font-medium">Likelihood</span>
                            <span className="text-sm text-gray-600">
                              {Math.round(selectedDisease.likelihood * 100)}%
                            </span>
                          </div>
                          <Progress value={selectedDisease.likelihood * 100} className="h-2" />
                        </div>
                      )}

                      {selectedDisease.reason && (
                        <div>
                          <span className="font-medium block mb-2">Reason for Selection:</span>
                          <p className="text-sm text-gray-700 bg-white p-3 rounded border">{selectedDisease.reason}</p>
                        </div>
                      )}

                      {!selectedDisease.likelihood && !selectedDisease.reason && (
                        <p className="text-sm text-gray-600 italic">
                          Additional details not available for this condition.
                        </p>
                      )}
                    </div>

                    <Button variant="outline" className="mt-4 bg-transparent" onClick={() => setSelectedDisease(null)}>
                      Back to List
                    </Button>
                  </div>
                </CardContent>
              </Card>
            )}

            <Card>
              <CardHeader>
                <CardTitle className="text-xl">Clarifying Questions</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-2 gap-3">
                  {apiResponse.clarifying_questions.map((question, index) => (
                    <div key={index} className="flex items-center gap-2">
                      <div className="w-2 h-2 bg-blue-600 rounded-full flex-shrink-0"></div>
                      <span className="text-sm">{question}</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </>
        )}
      </div>
    </div>
  )
}
